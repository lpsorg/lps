/* If you're feeling fancy you can add interactivity 
    to your site with Javascript */

// prints "Welcome to XVIDEO" in the browser's dev tools console
console.log("Welcome to XVIDEO");